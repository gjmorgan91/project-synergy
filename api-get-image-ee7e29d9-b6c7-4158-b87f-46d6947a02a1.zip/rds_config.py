db_username = 'admin'
db_password = 'passatword1'
db_name = 'image_rekognition'