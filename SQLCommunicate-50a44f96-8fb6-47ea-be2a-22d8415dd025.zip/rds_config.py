#config file containing credentials for RDS MySQL instance
db_username = "admin"
db_password = "passatword1"
db_name = "image_rekognition" 