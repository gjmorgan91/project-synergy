# project-synergy

Project Synergy Hackathon AWS Reokongition app