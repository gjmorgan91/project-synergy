export default {
    orange: '#FF9900',
    red: '#CD0000',
    blue: '#24A0ED'
}